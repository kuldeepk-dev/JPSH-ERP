<?php

return [
    'name' => 'RazorPay'
];
